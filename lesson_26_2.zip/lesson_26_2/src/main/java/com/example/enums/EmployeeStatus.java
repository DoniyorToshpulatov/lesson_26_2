package com.example.enums;

public enum EmployeeStatus {
    ACTIVE, BLOCK
}
